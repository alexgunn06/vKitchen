   </main>
    <footer style="background-color:#eee; padding:1rem; text-align:center; margin-top:2rem;">
        <p>&copy; <?= date("Y") ?> Virtual Kitchen. All rights reserved.</p>
    </footer>
</body>
</html>